import { Client, Account, Functions, ID } from 'https://cdn.jsdelivr.net/npm/appwrite/+esm';

const APPWRITE_ENDPOINT = 'https://nyc.cloud.appwrite.io/v1';
const APPWRITE_PROJECT_ID = '6ad1cfff0007e3e91e2b';
const FUNCTION_ID = 'sova-capitalbot';

const client = new Client().setEndpoint(APPWRITE_ENDPOINT).setProject(APPWRITE_PROJECT_ID);
const account = new Account(client);
const functions = new Functions(client);

const modal = document.getElementById('authModal');
const title = document.getElementById('authTitle');
const authText = document.getElementById('authText');
const submit = document.getElementById('authSubmit');
const form = document.getElementById('authForm');
const switchAuth = document.getElementById('switchAuth');
const verifyNote = document.getElementById('verifyNote');
const displayNameInput = document.getElementById('displayName');
const nameLabel = document.getElementById('nameLabel');
const ageConfirm = document.getElementById('ageConfirm');
const ageLabel = document.getElementById('ageLabel');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

const chatModal = document.getElementById('chatModal');
const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');
const sendButton = document.getElementById('sendChat');
const startButton = document.getElementById('startChat');
const startPanel = document.getElementById('chatStart');
const startText = document.getElementById('chatStartText');
const chatStatus = document.getElementById('chatStatus');
const signOutButton = document.getElementById('signOut');

let mode = 'signup';
let currentUser = null;
let currentConversationId = null;
let busy = false;

function setNote(message, isError = false) {
  verifyNote.hidden = !message;
  verifyNote.textContent = message || '';
  verifyNote.classList.toggle('error-note', Boolean(isError));
}

function openAuth(next = 'signup') {
  mode = next;
  title.textContent = mode === 'signup' ? 'Create your account' : 'Welcome back';
  authText.textContent = mode === 'signup'
    ? 'Join SOVA to start a private conversation with Laura.'
    : 'Sign in to continue your conversation.';
  submit.textContent = mode === 'signup' ? 'Create account' : 'Sign in';
  switchAuth.innerHTML = mode === 'signup'
    ? 'Already have an account? <b>Sign in</b>'
    : 'New to SOVA? <b>Create an account</b>';
  nameLabel.hidden = mode !== 'signup';
  displayNameInput.required = mode === 'signup';
  displayNameInput.autocomplete = mode === 'signup' ? 'name' : 'off';
  ageLabel.hidden = mode !== 'signup';
  ageConfirm.required = mode === 'signup';
  passwordInput.autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  setNote('');
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  setTimeout(() => (mode === 'signup' ? displayNameInput : emailInput).focus(), 30);
}

function closeAuth() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  form.reset();
  setNote('');
}

function closeChat() {
  chatModal.classList.remove('open');
  chatModal.setAttribute('aria-hidden', 'true');
}

function openChatSurface() {
  closeAuth();
  chatModal.classList.add('open');
  chatModal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('chat-open');
  void loadHistory();
  void refreshChatStatus();
}

function closeAllOverlays() {
  closeAuth();
  closeChat();
  document.body.classList.remove('chat-open');
}

function cleanUserFacingError(error, fallback = 'SOVA could not complete that request. Please try again in a moment.') {
  const code = String(error?.type || error?.code || '');
  const message = String(error?.message || '');
  if (/user_already_exists/i.test(code + ' ' + message)) return 'An account already exists for this email. Please sign in instead.';
  if (/user_invalid_credentials/i.test(code + ' ' + message)) return 'That email and password do not match. Please try again.';
  if (/password.*(short|weak)|user_password_too_short/i.test(code + ' ' + message)) return 'Choose a password with at least 8 characters.';
  if (/rate_limit|too many/i.test(code + ' ' + message)) return 'Too many attempts too quickly. Please wait a little and try again.';
  return fallback;
}

async function getSignedInUser() {
  try {
    currentUser = await account.get();
    return currentUser;
  } catch {
    currentUser = null;
    return null;
  }
}

async function callProxy(payload) {
  if (!currentUser) throw new Error('Please sign in to continue.');
  const jwtResult = await account.createJWT();
  const token = jwtResult?.jwt;
  if (!token) throw new Error('Please sign in again to continue.');
  const execution = await functions.createExecution({
    functionId: FUNCTION_ID,
    body: JSON.stringify(payload),
    async: false,
    xpath: '/',
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-appwrite-user-jwt': token,
    },
  });

  const responseText = execution?.responseBody ?? execution?.response ?? '';
  let result = {};
  if (typeof responseText === 'string') {
    try { result = responseText ? JSON.parse(responseText) : {}; }
    catch { throw new Error('SOVA received an unreadable response. Please try again.'); }
  } else if (responseText && typeof responseText === 'object') {
    result = responseText;
  }
  const status = Number(execution?.responseStatusCode ?? execution?.statusCode ?? 0);
  if ((status >= 400 && status !== 0) || result.ok === false) {
    const error = new Error(result.message || 'The chat service is temporarily unavailable.');
    error.code = result.code || 'CHAT_UNAVAILABLE';
    error.status = status;
    throw error;
  }
  return result;
}

function setChatStatus(message) {
  chatStatus.textContent = message;
}

async function refreshChatStatus() {
  setChatStatus('Checking chat availability…');
  try {
    const result = await callProxy({ action: 'status' });
    setChatStatus(result.capitalAIReady ? 'Chat is online' : 'Chat setup in progress');
  } catch {
    setChatStatus('Private chat');
  }
}

function validMediaUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url.href : '';
  } catch {
    return '';
  }
}

function makeMediaElement(rawContent) {
  const match = rawContent.match(/^\[\[(image|video|audio)\]\]:(.+)$/s);
  if (!match) return null;
  const kind = match[1];
  const src = validMediaUrl(match[2].trim());
  if (!src) return null;
  let element;
  if (kind === 'image') {
    element = document.createElement('img');
    element.alt = 'Media shared in the conversation';
    element.loading = 'lazy';
    element.src = src;
    element.addEventListener('error', () => { element.replaceWith(document.createTextNode('This image is unavailable.')); }, { once: true });
  } else if (kind === 'video') {
    element = document.createElement('video');
    element.controls = true;
    element.playsInline = true;
    element.preload = 'metadata';
    element.src = src;
  } else {
    element = document.createElement('audio');
    element.controls = true;
    element.preload = 'metadata';
    element.src = src;
  }
  return element;
}

function appendMessage(message) {
  const role = message?.role === 'user' ? 'user' : 'assistant';
  const content = String(message?.content || '');
  if (!content) return;
  const bubble = document.createElement('div');
  bubble.className = `real-bubble ${role}`;
  const media = makeMediaElement(content);
  if (media) {
    bubble.appendChild(media);
  } else {
    bubble.textContent = content.startsWith('[[') ? 'Media could not be displayed.' : content;
  }
  chatMessages.appendChild(bubble);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function renderMessages(messages) {
  chatMessages.replaceChildren();
  for (const message of (Array.isArray(messages) ? messages : [])) appendMessage(message);
  const hasMessages = Array.isArray(messages) && messages.length > 0;
  startPanel.hidden = hasMessages;
  chatForm.hidden = !hasMessages;
  if (!hasMessages) startText.textContent = 'Whenever you’re ready, say hello. 🤍';
}

function showSystemMessage(message) {
  appendMessage({ role: 'assistant', content: message });
}

async function loadHistory() {
  if (!currentUser) return;
  setChatStatus('Opening your conversation…');
  try {
    const result = await callProxy({ action: 'history' });
    currentConversationId = result.conversationId || null;
    renderMessages(result.messages || []);
    setChatStatus('Private conversation · AI-assisted');
  } catch (error) {
    setChatStatus('Private conversation');
    renderMessages([]);
    startText.textContent = cleanUserFacingError(error, 'Your private chat is loading. Please try again shortly.');
  }
}

async function startConversation() {
  if (busy || !currentUser) return;
  busy = true;
  startButton.disabled = true;
  startButton.textContent = 'Opening chat…';
  setChatStatus('Opening your conversation…');
  try {
    const result = await callProxy({ action: 'start' });
    currentConversationId = result.conversationId || null;
    const messages = Array.isArray(result.messages) ? result.messages : [];
    renderMessages(messages);

    if (result.underage || result.reason === 'underage') {
      startPanel.hidden = false;
      chatForm.hidden = true;
      startText.textContent = 'This conversation cannot continue.';
      startButton.hidden = true;
    } else if (result.filtered) {
      startPanel.hidden = false;
      chatForm.hidden = true;
      startText.textContent = 'Laura can’t start this conversation right now. Please try again shortly.';
    } else {
      // A preset may not have an automatic opener. Do not trap the user in a
      // Start button loop: let the user send the first message instead.
      startPanel.hidden = true;
      chatForm.hidden = false;
      chatInput.placeholder = messages.length ? 'Write a message…' : 'Say hello to Laura…';
      chatInput.focus();
    }
    setChatStatus(result.filtered ? 'Chat unavailable right now' : 'Private conversation · AI-assisted');
  } catch (error) {
    startPanel.hidden = false;
    chatForm.hidden = true;
    startText.textContent = cleanUserFacingError(error, 'Laura’s chat could not start. Please try again shortly.');
    setChatStatus('Chat connection needs attention');
  } finally {
    busy = false;
    startButton.disabled = false;
    startButton.textContent = 'Start conversation';
  }
}

async function sendMessage(event) {
  event.preventDefault();
  if (busy || !currentUser) return;
  const message = chatInput.value.trim();
  if (!message) return;
  if (message.length > 2000) {
    showSystemMessage('Please keep each message under 2,000 characters.');
    return;
  }
  busy = true;
  chatInput.disabled = true;
  sendButton.disabled = true;
  setChatStatus('Laura is replying…');
  try {
    const result = await callProxy({ action: 'send', conversationId: currentConversationId || undefined, message });
    currentConversationId = result.conversationId || currentConversationId;
    if (result.userMessage) appendMessage(result.userMessage);
    for (const reply of (result.messages || [])) appendMessage(reply);
    if (result.underage || result.reason === 'underage') {
      showSystemMessage('This conversation has been ended.');
      chatForm.hidden = true;
    } else if (result.filtered && !(result.messages || []).length) {
      showSystemMessage('Laura can’t reply to this message right now.');
    }
    chatInput.value = '';
    setChatStatus('Private conversation · AI-assisted');
  } catch (error) {
    // A failed API call may have saved the user message before the upstream request failed.
    await loadHistory();
    showSystemMessage(cleanUserFacingError(error, 'Laura couldn’t reply just now. Please try again in a moment.'));
    setChatStatus('Reply unavailable right now');
  } finally {
    busy = false;
    chatInput.disabled = false;
    sendButton.disabled = false;
    chatInput.focus();
  }
}

function verificationCallbackUrl() {
  const url = new URL(window.location.pathname, window.location.origin);
  url.searchParams.set('verify', '1');
  return url.toString();
}

async function endCurrentSession() {
  try { await account.deleteSession({ sessionId: 'current' }); } catch { /* No active session to clear. */ }
  currentUser = null;
}

async function submitAuth(event) {
  event.preventDefault();
  if (busy) return;
  const submittedMode = mode;
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  const displayName = displayNameInput.value.trim();
  if (submittedMode === 'signup' && !ageConfirm.checked) {
    setNote('You must confirm that you are 18 or older to create an account.', true);
    return;
  }
  if (submittedMode === 'signup' && displayName.length < 1) {
    setNote('Please enter a display name.', true);
    return;
  }

  busy = true;
  submit.disabled = true;
  submit.textContent = submittedMode === 'signup' ? 'Creating account…' : 'Signing in…';
  setNote('');
  try {
    if (submittedMode === 'signup') {
      await account.create({ userId: ID.unique(), email, password, name: displayName });

      let sessionStarted = false;
      let verificationSent = false;
      let verificationError = null;
      try {
        await account.createEmailPasswordSession({ email, password });
        sessionStarted = true;
        currentUser = await account.get();
        await account.createVerification({ url: verificationCallbackUrl() });
        verificationSent = true;
      } catch (error) {
        verificationError = error;
      } finally {
        if (sessionStarted) {
          try { await account.deleteSession({ sessionId: 'current' }); } catch { /* Sign-up verification must not keep the user signed in. */ }
        }
        currentUser = null;
      }

      form.reset();
      openAuth('signin');
      emailInput.value = email;
      passwordInput.value = '';
      if (verificationSent) {
        setNote('Your account was created. We sent a verification link to your email. Open it to confirm your address, then sign in here. Check Spam/Junk if you do not see it.');
      } else {
        setNote('Your account was created, but SOVA could not send the verification email. Try signing in to request another link. If it still fails, the project email service needs attention. ' + (verificationError?.message ? `Details: ${verificationError.message}` : ''), true);
      }
      return;
    }

    await account.createEmailPasswordSession({ email, password });
    currentUser = await account.get();
    if (!currentUser.emailVerification) {
      let verificationSent = false;
      let verificationError = null;
      try {
        await account.createVerification({ url: verificationCallbackUrl() });
        verificationSent = true;
      } catch (error) {
        verificationError = error;
      }
      await endCurrentSession();
      passwordInput.value = '';
      setNote(verificationSent
        ? 'Your email is not verified yet. We sent you a fresh verification link. Confirm your email, then sign in again.'
        : `Your email is not verified, and SOVA could not send a verification link. ${verificationError?.message || 'Please try again later.'}`, !verificationSent);
      return;
    }

    openChatSurface();
  } catch (error) {
    setNote(cleanUserFacingError(error, submittedMode === 'signup'
      ? 'We couldn’t create your account. Check the details and try again.'
      : 'We couldn’t sign you in. Check your details and try again.'), true);
  } finally {
    busy = false;
    submit.disabled = false;
    submit.textContent = mode === 'signup' ? 'Create account' : 'Sign in';
  }
}

// Main site actions
for (const button of document.querySelectorAll('[data-open]')) {
  button.addEventListener('click', async () => {
    if (await getSignedInUser()) openChatSurface();
    else openAuth(button.dataset.open);
  });
}
for (const button of document.querySelectorAll('[data-close]')) button.addEventListener('click', closeAuth);
switchAuth.addEventListener('click', () => openAuth(mode === 'signup' ? 'signin' : 'signup'));
form.addEventListener('submit', submitAuth);
startButton.addEventListener('click', startConversation);
chatForm.addEventListener('submit', sendMessage);
for (const button of document.querySelectorAll('[data-chat-close]')) button.addEventListener('click', () => { closeChat(); document.body.classList.remove('chat-open'); });
signOutButton.addEventListener('click', async () => {
  try { await account.deleteSession({ sessionId: 'current' }); } catch { /* A stale session is already signed out. */ }
  currentUser = null;
  currentConversationId = null;
  renderMessages([]);
  closeAllOverlays();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeAllOverlays();
});

// Complete Appwrite email verification when a user returns from the email link.
async function handleEmailVerificationCallback() {
  const params = new URLSearchParams(window.location.search);
  const userId = params.get('userId');
  const secret = params.get('secret');
  if (!userId || !secret) return;

  openAuth('signin');
  try {
    await account.updateVerification({ userId, secret });
    const cleanUrl = new URL(window.location.href);
    cleanUrl.searchParams.delete('userId');
    cleanUrl.searchParams.delete('secret');
    cleanUrl.searchParams.delete('verify');
    window.history.replaceState({}, document.title, cleanUrl.pathname + cleanUrl.search + cleanUrl.hash);
    setNote('Email confirmed successfully. You can now sign in to SOVA.');
    emailInput.focus();
  } catch (error) {
    setNote('This verification link may have expired or already been used. Sign in to request a new link. ' + (error?.message || ''), true);
  }
}

// Restore the session silently after a page refresh; don't automatically open the chat.
void getSignedInUser();
void handleEmailVerificationCallback();
