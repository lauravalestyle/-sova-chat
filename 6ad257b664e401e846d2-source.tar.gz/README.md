# SOVA — social-style Laura chat

This is the first visual build based on the requested direction:
- Social-media/app identity rather than a Laura Vale personal landing page.
- Dark, seductive, premium interface with pink/violet accents.
- Laura selfie used as the hero visual and chat/profile avatar.
- Social-style navigation, profile card, message preview, sign-up/sign-in modal.
- Mobile-first responsive design.

## Important
"SOVA" is a working brand name, not a confirmed trademark/domain choice. Check domain and trademark availability before launch.

## Implemented integrations
1. Appwrite email/password authentication.
2. Email verification email and return-link handling.
3. Authenticated requests to the server-side `sova-capitalbot` function.
4. A higher-resolution Laura image for the full-height hero.

The CapitalBot license key stays server-side. The `start` flow opens the message composer when the preset does not return an automatic opener, instead of trapping the user behind the Start button. Privacy Policy and Terms still need final content before public launch.
